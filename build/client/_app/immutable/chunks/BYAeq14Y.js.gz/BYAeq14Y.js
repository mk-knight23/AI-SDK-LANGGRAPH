import{f as a}from"./BlsAYwGw.js";a();
